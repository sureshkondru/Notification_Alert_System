import logging

def determine_recipient(request_data):
    try:
        # Example logic to determine recipient
        if 'admin_id' in request_data:
            recipient = request_data['admin_id']
        else:
            recipient = 'default_recipient'
        
        if recipient == 'default_recipient':
            recipient = 'admin'  # Treat 'default_recipient' as 'admin'
        
        logging.info(f"Recipient determined: {recipient}")
        return recipient
    except Exception as e:
        logging.error(f"Error determining recipient: {e}")
        return 'admin'  # Default to 'admin' on error
