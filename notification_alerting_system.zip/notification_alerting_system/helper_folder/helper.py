import platform
import subprocess
from plyer import notification
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)

def send_notification(candidate_info, recipient):
    try:
        logging.info(f"Sending notification to recipient: {recipient} with info: {candidate_info}")
        
        # Example: Check recipient and send notification based on recipient's role or ID
        if recipient == 'admin':
            send_admin_notification(candidate_info)
        elif recipient == 'super_admin':
            send_super_admin_notification(candidate_info)
        elif recipient == 'default_recipient':
            send_default_recipient(candidate_info)
        else:
            raise ValueError(f"Invalid recipient: {recipient}")

        # Return the updated candidate info
        return candidate_info

    except Exception as e:
        logging.error(f"Error sending notification: {e}")
        return None

def send_admin_notification(candidate_info):
    send_desktop_notification("Admin Notification", format_message(candidate_info))

def send_super_admin_notification(candidate_info):
    send_desktop_notification("Super Admin Notification", format_message(candidate_info))

def send_default_recipient(candidate_info):
    send_desktop_notification("Default Recipient Notification", format_message(candidate_info))

def send_desktop_notification(title, message):
    try:
        if platform.system() == "Darwin":
            subprocess.run(['osascript', '-e', f'display notification "{message}" with title "{title}"'])
        elif platform.system() == "Linux":
            subprocess.run(['notify-send', title, message])
        elif platform.system() == "Windows":
            notification.notify(
                title=title,
                message=message
            )
        logging.info("Notification sent successfully.")

    except Exception as e:
        logging.error(f"Error sending desktop notification: {e}")

def format_message(candidate_info):
    name = candidate_info.get('user_id', '')
    business_unit = candidate_info.get('business_unit', '')
    job_title = candidate_info.get('job_title', '')
    job_description = candidate_info.get('job_description', '')
    max_years_exp = candidate_info.get('max_years_exp', '')
    user_email = candidate_info.get('user_email', '')

    message = (
        f"Candidate Name: {name}\n"
        f"Business Unit: {business_unit}\n"
        f"Job Title: {job_title}\n"
        f"Job Description: {job_description}\n"
        f"Max Years of Experience: {max_years_exp}\n"
        f"User Email: {user_email}"
    )
    return message
