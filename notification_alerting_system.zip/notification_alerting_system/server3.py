from flask import Flask, request, jsonify, send_from_directory, render_template
from flask_socketio import SocketIO, emit
from apscheduler.schedulers.background import BackgroundScheduler
from bll.bllengine import create_request
from Data_base.database_config import get_db_connection
from helper_folder.helper import send_notification
from recipient_logic import determine_recipient
import logging
import atexit
from flask_cors import CORS

# Configure logging
logging.basicConfig(level=logging.INFO)

# Initialize Flask app, Socket.IO, and CORS
app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")
CORS(app)

# Dictionary to keep track of connected users
connected_users = {}

# Socket.IO event for handling connections
@socketio.on('connect')
def handle_connect():
    user_id = request.args.get('user_id')  # Assuming user_id is passed as a query parameter
    if user_id:
        connected_users[user_id] = request.sid
        logging.info(f'Client connected: {user_id}')
    else:
        logging.warning('Client connected without user_id')

# Socket.IO event for handling disconnections
@socketio.on('disconnect')
def handle_disconnect():
    user_id = None
    for uid, sid in connected_users.items():
        if sid == request.sid:
            user_id = uid
            break
    if user_id:
        del connected_users[user_id]
        logging.info(f'Client disconnected: {user_id}')
    else:
        logging.warning('Client disconnected with unknown user_id')

# Function to periodically check job requests and send notifications
def check_new_job_requests():
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        query = "SELECT * FROM job_opening_requests WHERE status = 'new'"
        cursor.execute(query)
        rows = cursor.fetchall()

        for row in rows:
            candidate_info = {
                'name': row['user_id'],
                'business_unit': row['business_unit'],
                'job_title': row['job_title'],
                'job_description': row['job_description'],
                'max_years_exp': row['max_years_exp'],
                'user_email': row['user_email']
            }

            recipient = determine_recipient(row)
            logging.info(f"Determined recipient: {recipient} for user: {row['user_id']}")

            success = send_notification(candidate_info, recipient)

            if success:
                update_query = "UPDATE job_opening_requests SET status = 'notified' WHERE job_request_id = %s"
                cursor.execute(update_query, (row['job_request_id'],))
                connection.commit()

                if recipient in connected_users:
                    # Emit notification to specific recipient if connected
                    socketio.emit('notification', candidate_info, room=connected_users[recipient])

        cursor.close()
        connection.close()

    except Exception as e:
        logging.error(f"Error in check_new_job_requests: {e}")

# Scheduler to run check_new_job_requests every 60 seconds
scheduler = BackgroundScheduler()
scheduler.add_job(func=check_new_job_requests, trigger="interval", seconds=60)
scheduler.start()

# API endpoint to handle desktop notifications
@app.route('/Desktop_notification', methods=['POST'])
def desktop_notification():
    try:
        data = request.get_json()

        # Extract request_data from JSON
        request_data = data.get('request_data', {})

        # Prepare candidate information
        candidate_info = {
            'reporting_manager': request_data.get('reporting_manager', ''),
            'business_unit': request_data.get('business_unit', ''),
            'user_email': request_data.get('user_email', ''),
            'admin_id': request_data.get('admin_id', ''),
            'name': request_data.get('name', ''),
            'job_title': request_data.get('job_title', ''),
            'max_years_exp': request_data.get('max_years_exp', ''),
            'company': request_data.get('company', ''),
        }

        # Determine recipient based on your application logic
        recipient = determine_recipient(request_data)
        logging.info(f"Determined recipient: {recipient} for request data: {request_data}")

        if recipient == 'default_recipient':
            raise ValueError("Invalid recipient: default_recipient")

        # Send notification with recipient and get the updated candidate_info
        updated_candidate_info = send_notification(candidate_info, recipient)

        if updated_candidate_info:
            # Emit notification to specific recipient if connected
            if recipient in connected_users:
                socketio.emit('notification', updated_candidate_info, room=connected_users[recipient])
            return jsonify(updated_candidate_info), 200  # Return the updated candidate_info
        else:
            return jsonify({"status": "failure"}), 500

    except KeyError as ke:
        logging.error(f"Missing field in request data: {str(ke)}")
        return jsonify({"status": "error", "message": f"Missing field: {str(ke)}"}), 400

    except ValueError as ve:
        logging.error(f"Value error: {str(ve)}")
        return jsonify({"status": "error", "message": str(ve)}), 400

    except Exception as e:
        logging.error(f"Error in desktop_notification endpoint: {str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500

# API endpoint to add job requests
@app.route('/add_job_request', methods=['POST'])
def add_job_request():
    try:
        data = request.get_json().get('request_data', {})
        data['min_salary'] = data.get('min_salary') or None
        data['max_salary'] = data.get('max_salary') or None
        data['approved_on'] = data.get('approved_on') or None

        success = create_request('job_opening_requests', data)

        if success:
            return jsonify({"status": "success"}), 200
        else:
            return jsonify({"status": "failure"}), 500

    except Exception as e:
        logging.error(f"Error in add_job_request endpoint: {str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500

# Default route
@app.route('/')
def index():
    return render_template('notification.html')

# Shutdown scheduler when exiting the app
atexit.register(lambda: scheduler.shutdown())

# Main entry point
if __name__ == '__main__':
    socketio.run(app, port=5000, debug=True)
