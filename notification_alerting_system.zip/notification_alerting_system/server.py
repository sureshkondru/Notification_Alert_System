# Import necessary modules
from flask import Flask, request, jsonify
from flask_socketio import SocketIO
from apscheduler.schedulers.background import BackgroundScheduler
from bll.bllengine import create_request
from Data_base.database_config import get_db_connection
from helper_folder.helper import send_notification
from recipient_logic import determine_recipient
import atexit
from flask_cors import CORS
import sys
import logging
import uuid  # Import the uuid module

# Initialize Flask app, SocketIO, and CORS
app = Flask(__name__)
socketio = SocketIO(app)
CORS(app)

# Dictionary to keep track of connected users
connected_users = {}

# SocketIO event for handling connections
@socketio.on('connect')
def handle_connect():
    user_id = request.args.get('user_id')  # Assuming user_id is passed as a query parameter
    if user_id:
        connected_users[user_id] = request.sid
        print(f'Client connected: {user_id}')
    else:
        print('Client connected without user_id')

# SocketIO event for handling disconnections
@socketio.on('disconnect')
def handle_disconnect():
    user_id = None
    for uid, sid in connected_users.items():
        if sid == request.sid:
            user_id = uid
            break
    if user_id:
        del connected_users[user_id]
        print(f'Client disconnected: {user_id}')
    else:
        print('Client disconnected with unknown user_id')

# Function to periodically check job requests and send notifications
def check_new_job_requests():
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        query = "SELECT * FROM job_opening_requests WHERE status = 'new'"
        cursor.execute(query)
        rows = cursor.fetchall()

        for row in rows:
            candidate_info = {
                'name': row['user_id'],
                'business_unit': row['business_unit'],
                'job_title': row['job_title'],
                'job_description': row['job_description'],
                'max_years_exp': row['max_years_exp'],
                'user_email': row['user_email']
            }

            recipient = determine_recipient(row)
            print(f"Determined recipient: {recipient} for user: {row['user_id']}")

            success = send_notification(candidate_info, recipient)

            if success:
                update_query = "UPDATE job_opening_requests SET status = 'notified' WHERE job_request_id = %s"
                cursor.execute(update_query, (row['job_request_id'],))
                connection.commit()

                if recipient in connected_users:
                    # Emit notification to specific recipient if connected
                    socketio.emit('notification', candidate_info, room=connected_users[recipient])

        cursor.close()
        connection.close()

    except Exception as e:
        print(f"Error in check_new_job_requests: {e}")

# Scheduler to run check_new_job_requests every 60 seconds
scheduler = BackgroundScheduler()
scheduler.add_job(func=check_new_job_requests, trigger="interval", seconds=60)
scheduler.start()

# API endpoint to handle desktop notifications
@app.route('/Desktop_notification', methods=['POST'])
def desktop_notification():
    try:
        data = request.get_json()  # Retrieve JSON data from the request
        print("Received data:", data)  # Log the received data

        # Extract relevant fields from the request data
        request_data = data.get('request_data', {})
        print("Extracted request_data:", request_data)  # Log the extracted request_data

        # Validate required fields
        required_fields = ['business_unit', 'job_title', 'job_description', 'max_years_exp', 'user_email']
        for field in required_fields:
            if field not in request_data:
                print(f"Missing field: {field}")  # Log the missing field
                return jsonify({"status": "error", "message": f"Missing field: {field}"}), 400

        # Prepare candidate information for notification
        candidate_info = {
            'name': request_data['user_id'],  # Assuming 'user_id' is used as 'name' in candidate_info
            'business_unit': request_data['business_unit'],
            'job_title': request_data['job_title'],
            'job_description': request_data['job_description'],
            'max_years_exp': request_data['max_years_exp'],
            'user_email': request_data['user_email']
        }

        print("Candidate info prepared for notification:", candidate_info)

        # Determine recipient based on your application logic
        recipient = determine_recipient(request_data)
        print("Determined recipient:", recipient)
        if recipient == 'default_recipient':
            print("Invalid recipient: default_recipient")  # Log invalid recipient
            return jsonify({"status": "error", "message": "Invalid recipient: default_recipient"}), 400

        # Send notification with recipient and get the updated candidate_info
        updated_candidate_info = send_notification(candidate_info, recipient)
        print("Send notification result:", updated_candidate_info)

        if updated_candidate_info:
            return jsonify(updated_candidate_info), 200  # Return the updated candidate_info
        else:
            return jsonify({"status": "failure"}), 500

    except KeyError as ke:
        return jsonify({"status": "error", "message": f"Missing field in request data: {str(ke)}"}), 400

    except ValueError as ve:
        return jsonify({"status": "error", "message": str(ve)}), 400

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# API endpoint to add job requests
@app.route('/add_job_request', methods=['POST'])
def add_job_request():
    try:
        data = request.get_json().get('request_data', {})

        # Validate required fields
        required_fields = ['job_title', 'business_unit', 'job_description', 'min_years_exp', 'max_years_exp', 'user_email','user_id']
        for field in required_fields:
            if field not in data:
                return jsonify({"status": "error", "message": f"Missing field: {field}"}), 400

        # Generate a unique user_id
        user_id = str(uuid.uuid4())
        data['user_id'] = user_id

        data['min_salary'] = data.get('min_salary') or None
        data['max_salary'] = data.get('max_salary') or None
        data['approved_on'] = data.get('approved_on') or None

        # Call create_request function here
        success = create_request('job_opening_requests', data)

        if success:
            return jsonify({"status": "success", "user_id": user_id}), 200
        else:
            return jsonify({"status": "failure"}), 500

    except Exception as e:
        print(f"Error in add_job_request endpoint: {str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500


# Shutdown scheduler when exiting the app
atexit.register(lambda: scheduler.shutdown())

# Main entry point
if __name__ == '__main__':
    app.run(debug=True)
    # Run Flask app with SocketIO
    #socketio.run(app, port=5000, debug=True)
